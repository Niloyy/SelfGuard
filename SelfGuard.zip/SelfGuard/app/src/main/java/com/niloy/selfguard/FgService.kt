package com.niloy.selfguard

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

object Fg { @Volatile var pkg: String = "" }

class FgService : AccessibilityService() {
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        val p = e?.packageName?.toString() ?: return
        if (p == "com.android.systemui" || p == packageName || p.contains("inputmethod") || p.contains("keyboard")) return
        Fg.pkg = p
    }
    override fun onInterrupt() {}
}
