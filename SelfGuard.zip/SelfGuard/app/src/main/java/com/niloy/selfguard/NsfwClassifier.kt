package com.niloy.selfguard

import android.content.Context
import android.graphics.Bitmap
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel

/** GantMan nsfw_model order: drawings, hentai, neutral, porn, sexy. Input 224x224 RGB /255. */
class NsfwClassifier(ctx: Context) {
    private val interp: Interpreter
    init {
        val fd = ctx.assets.openFd("nsfw.tflite")
        val buf = FileInputStream(fd.fileDescriptor).channel.map(FileChannel.MapMode.READ_ONLY, fd.startOffset, fd.declaredLength)
        interp = Interpreter(buf, Interpreter.Options().setNumThreads(2))
    }
    fun score(src: Bitmap): Float {
        val bmp = Bitmap.createScaledBitmap(src, 224, 224, true)
        val bb = ByteBuffer.allocateDirect(224 * 224 * 3 * 4).order(ByteOrder.nativeOrder())
        val px = IntArray(224 * 224); bmp.getPixels(px, 0, 224, 0, 0, 224, 224)
        for (p in px) {
            bb.putFloat(((p shr 16) and 0xFF) / 255f); bb.putFloat(((p shr 8) and 0xFF) / 255f); bb.putFloat((p and 0xFF) / 255f)
        }
        val out = Array(1) { FloatArray(5) }
        interp.run(bb, out)
        val o = out[0]
        return o[1] + o[3] + o[4] // hentai + porn + sexy
    }
}
