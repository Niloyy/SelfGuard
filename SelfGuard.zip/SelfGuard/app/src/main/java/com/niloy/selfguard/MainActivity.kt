package com.niloy.selfguard

import android.Manifest
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private val capture = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val d = r.data
        if (r.resultCode == RESULT_OK && d != null) {
            ContextCompat.startForegroundService(this, Intent(this, ScanService::class.java).putExtra("code", r.resultCode).putExtra("data", d))
        }
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val cfg = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(40), dp(20), dp(20)) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }.also { col.addView(it) }
        col.addView(TextView(this).apply { text = "SelfGuard"; textSize = 26f })
        val hasModel = assets.list("")?.contains("nsfw.tflite") == true
        col.addView(TextView(this).apply { text = if (hasModel) "Model: ache" else "Model: NEI (assets/nsfw.tflite lagbe)"; setPadding(0, dp(8), 0, dp(16)) })
        col.addView(TextView(this).apply { text = "Sensitivity (beshi = beshi catch, beshi false alarm)" })
        val sens = SeekBar(this).apply { max = 90; progress = cfg.getInt("sens", 55).coerceIn(10, 90)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) { cfg.edit().putInt("sens", p.coerceAtLeast(10)).apply() }
                override fun onStartTrackingTouch(s: SeekBar) {}; override fun onStopTrackingTouch(s: SeekBar) {} }) }
        col.addView(sens)
        col.addView(TextView(this).apply { text = "Freeze somoy (minute)"; setPadding(0, dp(12), 0, 0) })
        val mins = SeekBar(this).apply { max = 9; progress = (cfg.getInt("secs", 120) / 60 - 1).coerceIn(0, 9)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) { cfg.edit().putInt("secs", (p + 1) * 60).apply() }
                override fun onStartTrackingTouch(s: SeekBar) {}; override fun onStopTrackingTouch(s: SeekBar) {} }) }
        col.addView(mins)
        col.addView(Switch(this).apply { text = "Shudhu Instagram e scan"; isChecked = cfg.getBoolean("only_ig", true)
            setOnCheckedChangeListener { _, c -> cfg.edit().putBoolean("only_ig", c).apply() } })
        btn("1. Overlay permission dao") { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        btn("2. Accessibility e SelfGuard on koro") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("3. START") {
            if (!Settings.canDrawOverlays(this)) Toast.makeText(this, "Age overlay permission dao", Toast.LENGTH_LONG).show()
            else {
                if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                capture.launch((getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).createScreenCaptureIntent())
            }
        }
        btn("STOP") { stopService(Intent(this, ScanService::class.java)) }
        setContentView(ScrollView(this).apply { addView(col) })
    }
}
