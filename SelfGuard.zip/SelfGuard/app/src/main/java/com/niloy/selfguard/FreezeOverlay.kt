package com.niloy.selfguard

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.CountDownTimer
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

object FreezeOverlay {
    fun show(ctx: Context, seconds: Int, onDone: () -> Unit) {
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val root = FrameLayout(ctx).apply { setBackgroundColor(Color.BLACK); setOnTouchListener { _, _ -> true } }
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        val icon = TextView(ctx).apply { text = "\uD83E\uDDD8"; textSize = 90f; gravity = Gravity.CENTER }
        val msg = TextView(ctx).apply { text = "Thama. Nishash nao. Ei content ta tomar jonno noy."; setTextColor(Color.WHITE); textSize = 18f; gravity = Gravity.CENTER; setPadding(60, 30, 60, 30) }
        val tv = TextView(ctx).apply { setTextColor(Color.WHITE); textSize = 40f; gravity = Gravity.CENTER }
        col.addView(icon); col.addView(msg); col.addView(tv)
        root.addView(col, FrameLayout.LayoutParams(-1, -1))
        val pulse = ObjectAnimator.ofFloat(icon, View.SCALE_X, 0.7f, 1.3f).apply { duration = 2500; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE }
        val pulseY = ObjectAnimator.ofFloat(icon, View.SCALE_Y, 0.7f, 1.3f).apply { duration = 2500; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE }
        pulse.start(); pulseY.start()
        val lp = WindowManager.LayoutParams(-1, -1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.OPAQUE)
        wm.addView(root, lp)
        object : CountDownTimer(seconds * 1000L, 1000) {
            override fun onTick(ms: Long) { val s = ms / 1000; tv.text = "%d:%02d".format(s / 60, s % 60) }
            override fun onFinish() { pulse.cancel(); pulseY.cancel(); try { wm.removeView(root) } catch (_: Exception) {}; onDone() }
        }.start()
    }
}
