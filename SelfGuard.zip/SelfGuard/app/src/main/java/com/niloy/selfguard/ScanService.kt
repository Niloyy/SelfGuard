package com.niloy.selfguard

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.widget.Toast
import androidx.core.app.ServiceCompat
import androidx.core.content.IntentCompat

class ScanService : Service() {
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
    private var classifier: NsfwClassifier? = null
    private val main = Handler(Looper.getMainLooper())
    private val thread = HandlerThread("sg-scan").also { it.start() }
    private val bg = Handler(thread.looper)
    private var hits = 0
    @Volatile private var frozen = false
    private val targets = setOf("com.instagram.android")

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getIntExtra("code", 0) ?: 0
        val data = intent?.let { IntentCompat.getParcelableExtra(it, "data", Intent::class.java) }
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("sg", "SelfGuard", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "sg").setContentTitle("SelfGuard cholche").setSmallIcon(android.R.drawable.ic_lock_lock).build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        try { classifier = NsfwClassifier(this) } catch (e: Exception) {
            Toast.makeText(this, "nsfw.tflite model nai (assets e dao)", Toast.LENGTH_LONG).show(); stopSelf(); return START_NOT_STICKY
        }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection!!.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, main)
        val dm = resources.displayMetrics
        val w = dm.widthPixels / 2; val h = dm.heightPixels / 2
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        vd = projection!!.createVirtualDisplay("sg", w, h, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null)
        bg.postDelayed(tick, 1500)
        return START_NOT_STICKY
    }

    private val tick = object : Runnable {
        override fun run() { try { scan() } catch (_: Exception) {}; bg.postDelayed(this, 1000) }
    }

    private fun scan() {
        val cfg = getSharedPreferences("cfg", MODE_PRIVATE)
        val img = reader?.acquireLatestImage() ?: return
        if (frozen || (cfg.getBoolean("only_ig", true) && Fg.pkg !in targets)) { img.close(); hits = 0; return }
        val pl = img.planes[0]; val rs = pl.rowStride; val ps = pl.pixelStride
        val full = Bitmap.createBitmap(rs / ps, img.height, Bitmap.Config.ARGB_8888)
        full.copyPixelsFromBuffer(pl.buffer)
        val bmp = Bitmap.createBitmap(full, 0, 0, img.width, img.height)
        img.close()
        val threshold = 1f - cfg.getInt("sens", 55) / 100f
        val s = classifier!!.score(bmp)
        hits = if (s >= threshold) hits + 1 else 0
        if (hits >= 2) {
            hits = 0; frozen = true
            main.post { FreezeOverlay.show(this, cfg.getInt("secs", 120)) { frozen = false } }
        }
    }

    override fun onDestroy() {
        bg.removeCallbacksAndMessages(null); thread.quitSafely()
        vd?.release(); reader?.close(); projection?.stop(); classifier = null
        super.onDestroy()
    }
}
